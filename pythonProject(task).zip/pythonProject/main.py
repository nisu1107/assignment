from flask import Flask, render_template, request
import openai

# set your OpenAI API key
openai.api_key = "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"

app = Flask(__name__)



def handle_openai_error(error):
    return render_template("error.html", message="OpenAI API error occurred.")


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/result", methods=["POST"])
def result():
    prompt = request.form["prompt"]
    try:
        # call the OpenAI API with the user's prompt
        response = openai.Completion.create(
            engine="davinci", prompt=prompt, max_tokens=100
        )
        message = response.choices[0].text.strip()
        return render_template("result.html", message=message)
    except openai.Error as e:
        # handle any OpenAI API errors
        return handle_openai_error(e)


if __name__ == "__main__":
    app.run(debug=True)
